package course.springdata.restmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestmvcDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
