package com.softuni.springintroex.services;

import java.io.IOException;

public interface BookService {
    void seedBooks() throws IOException;
}
