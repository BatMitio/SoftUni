public class Main {
    public static void main(String[] args) {
        Homework homework = new Homework();
        homework.setConnection("root", "root");
        //homework.getVillainsNamesEx2();
        //homework.getMinionNamesEx3();
        //homework.addMinionEx4();
        //homework.changeTownNamesCasingEx5();
        //homework.removeVillainEx6();
        //homework.printAllMinionsNamesEx7();
        //homework.increaseMinionsAgeEx8();
        //homework.increaseAgeStoredProcedureEx9();
    }
}
