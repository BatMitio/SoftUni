package entities.hospitalDB;

import entities.BaseEntity;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "visits")
public class Visit extends BaseEntity {
    private Patient patient;


    @ManyToOne(targetEntity = Patient.class, cascade = CascadeType.ALL)
    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    @Column(name = "visit_date")
    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    @ManyToOne(cascade = CascadeType.ALL)
    public Diagnose getDiagnose() {
        return diagnose;
    }

    public void setDiagnose(Diagnose diagnose) {
        this.diagnose = diagnose;
    }
    @ManyToOne(cascade = CascadeType.ALL)
    public Medicament getMedicament() {
        return medicament;
    }

    public void setMedicament(Medicament medicament) {
        this.medicament = medicament;
    }
    @OneToMany(mappedBy = "visit")
    public List<VisitComment> getComments() {
        return comments;
    }

    public void setComments(List<VisitComment> comments) {
        this.comments = comments;
    }

    private LocalDate date;
    private Diagnose diagnose;
    private Medicament medicament;
    private List<VisitComment> comments;

    public Visit() {
    }

}
