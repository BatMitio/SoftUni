package entities.hospitalDB;

import javax.persistence.*;

@Entity
@Table(name = "diagnose_comments")
public class DiagnoseComment extends Comment {

    @ManyToOne(cascade = CascadeType.ALL)
    public Diagnose getDiagnose() {
        return diagnose;
    }

    public void setDiagnose(Diagnose diagnose) {
        this.diagnose = diagnose;
    }

    private Diagnose diagnose;

    public DiagnoseComment() {
    }

}
