package entities.hospitalDB;

import entities.BaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;

@Entity
@Table(name = "diagnoses")
public class Diagnose extends BaseEntity {
    private String name;
    private List<DiagnoseComment> comments;
    private List<Visit> visits;

    @Column(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @OneToMany(mappedBy = "diagnose")
    public List<DiagnoseComment> getComments() {
        return comments;
    }

    public void setComments(List<DiagnoseComment> comments) {
        this.comments = comments;
    }

    @OneToMany(mappedBy = "diagnose")
    public List<Visit> getVisits() {
        return visits;
    }

    public void setVisits(List<Visit> visits) {
        this.visits = visits;
    }

    public Diagnose() {
    }
}
