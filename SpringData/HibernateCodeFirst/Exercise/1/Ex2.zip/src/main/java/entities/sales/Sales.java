package entities.sales;

import entities.BaseEntity;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "sales")
public class Sales extends BaseEntity {
    private Product product;
    private Customers customers;
    private StoreLocation store_location;
    private LocalDateTime date;


    @ManyToOne
    @JoinColumn(name = "products_id",referencedColumnName = "id")
    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
    @ManyToOne
    @JoinColumn(name = "customer_id",referencedColumnName = "id")
    public Customers getCustomers() {
        return customers;
    }

    public void setCustomers(Customers customers) {
        this.customers = customers;
    }
    @ManyToOne
    @JoinColumn(name = "store_location_id",referencedColumnName = "id")
    public StoreLocation getStore_location() {
        return store_location;
    }

    public void setStore_location(StoreLocation store_location) {
        this.store_location = store_location;
    }

    @Column(name = "date")
    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public Sales() {
    }
}
