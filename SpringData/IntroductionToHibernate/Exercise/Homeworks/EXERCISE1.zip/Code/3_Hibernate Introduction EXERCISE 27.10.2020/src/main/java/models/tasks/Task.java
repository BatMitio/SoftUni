package models.tasks;

public abstract class Task implements Runnable {
}